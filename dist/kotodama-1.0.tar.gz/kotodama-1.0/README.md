# kotodama
動詞を活用形に変換します
