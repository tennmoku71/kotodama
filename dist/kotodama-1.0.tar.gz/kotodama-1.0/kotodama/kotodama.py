# -*- coding: utf-8 -*-
 
def call():
    print("Trick or Treet")