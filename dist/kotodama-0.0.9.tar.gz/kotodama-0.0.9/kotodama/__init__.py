__copyright__    = 'Copyright (C) 2020 Yoshiki Ohira'
__version__      = '0.0.9'
__license__      = 'MIT'
__author__       = 'Yoshiki Ohira'
__author_email__ = 'ohira.yoshiki@irl.sys.es.osaka-u.ac.jp'
__url__          = 'https://github.com/tennmoku71'
__all__ = ['kotodama']